limepy
======

Human readable intro

Class
-----

.. autoclass::  limepy.limepy
   :members: __init__

Methods
-------

.. automethod:: limepy.limepy.df

