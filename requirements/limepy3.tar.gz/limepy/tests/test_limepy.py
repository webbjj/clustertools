#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_limepy
----------------------------------

Tests for `limepy` module.
"""

import unittest

from limepy import limepy


class Testlimepy(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
