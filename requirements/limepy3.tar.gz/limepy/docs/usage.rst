========
Usage
========

To use limepy in a project::

    import limepy

To import the class limepy::

    from limepy import limepy

.. include:: usageexamples.rst

